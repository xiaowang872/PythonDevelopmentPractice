# 模块的定义与使用
def echo(msg): # 消息响应
    return '【ECHO】' + msg





